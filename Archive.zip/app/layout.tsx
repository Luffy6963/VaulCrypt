import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Vaulcrypt - The Future of Secure Transactions',
  description: 'Vaulcrypt is developing a revolutionary platform for secure transactions. Our innovative system aims to protect your funds with cutting-edge security and seamless integration with various payment systems.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}